package com.ollacercana.core.models;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import com.ollacercana.core.models.enums.EstadoPlato;
import com.ollacercana.core.models.enums.RestriccionAlimentaria;
import com.ollacercana.core.models.enums.TipoAjustePorciones;
import com.ollacercana.core.models.enums.TipoComida;

/**
 * Dominio puro de un plato — sin anotaciones JPA.
 *
 * FEAT-05 — Oferta (OC-39)
 * HU-04   — Publicar oferta (OC-20)
 * HU-05   — Porciones y precio (OC-21)
 * HU-24   — Actualizar disponibilidad (OC-48)
 * RN-02   — Expiración a las 4h
 * RN-03   — Disponibles = totales - comprometidas
 * RN-27   — Precio entre 2000 y 50000, múltiplo de 100
 * RN-28   — Máximo 3 platos activos por cocinera
 * RN-29   — Un plato expirado no se puede modificar
 */
@Getter
@Setter
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class Plato {

    private UUID id;
    private UUID cocineraId;
    private String nombre;
    private String descripcion;
    private String fotoUrl;
    private TipoComida tipoComida;
    private List<RestriccionAlimentaria> restricciones;
    private Integer porcionesTotales;
    private Integer porcionesComprometidas;
    private BigDecimal precioPorcion;
    private EstadoPlato estado;
    private LocalDateTime horaDisponibilidad;
    private LocalDateTime fechaPublicacion;
    private LocalDateTime fechaExpiracion;
    private Double latitud;
    private Double longitud;
    private String puntoEntrega;
    private Integer version;                                           

    /**
     * RN-03: porciones disponibles = totales - comprometidas.
     *
     * @return disponibles, nunca negativo
     */
    public int getPorcionesDisponibles() {
        int comprometidas = porcionesComprometidas == null ? 0 : porcionesComprometidas;
        return porcionesTotales - comprometidas;
    }

    /**
     * RN-02 / RN-28: publica un plato calculando su fecha de expiración.
     *
     * OC-92 — Fecha de expiración +4h
     *
     * @throws IllegalStateException si el plato no tiene cocinera asociada
     */
    public void publicar() {
        if (this.cocineraId == null) {
            throw new IllegalStateException("Un plato no puede publicarse sin una cocinera asociada");
        }
        this.estado = EstadoPlato.ACTIVO;
        this.porcionesComprometidas = 0;
        this.fechaPublicacion = LocalDateTime.now(java.time.ZoneId.systemDefault());
        this.fechaExpiracion = this.fechaPublicacion.plusHours(4);
    }

    /** RN-03: cuando las disponibles llegan a 0, el plato pasa a AGOTADO. */
    public void marcarAgotado() {
        this.estado = EstadoPlato.AGOTADO;
    }

    /** RN-02: expiración automática. */
    public void expirar() {
        this.estado = EstadoPlato.EXPIRADO;
    }

    /**
     * RN-03: recalcula el estado segÃºn las porciones disponibles.
     *
     * OC-100 — calcularDisponibles()
     */
    public void recalcularEstado() {
        if (this.estado == EstadoPlato.EXPIRADO || this.estado == EstadoPlato.OCULTO) return;
        if (getPorcionesDisponibles() <= 0) {
            this.estado = EstadoPlato.AGOTADO;
        } else if (this.estado == EstadoPlato.AGOTADO) {
            this.estado = EstadoPlato.ACTIVO;
        }
    }

    /**
     * RN-03: descuenta porciones comprometidas (al reservar).
     *
     * OC-138 — ReservaService.crear()
     *
     * @throws IllegalArgumentException si cantidad <= 0
     * @throws IllegalStateException    si cantidad > disponibles
     */
    public void comprometerPorciones(int cantidad) {
        if (cantidad <= 0) {
            throw new IllegalArgumentException("La cantidad debe ser mayor a 0");
        }
        if (cantidad > getPorcionesDisponibles()) {
            throw new IllegalStateException(
                    "No hay suficientes porciones disponibles. Disponibles: " + getPorcionesDisponibles()
            );
        }
        this.porcionesComprometidas += cantidad;
        recalcularEstado();
    }

    /**
     * RN-03: libera porciones comprometidas (al cancelar/rechazar reserva).
     *
     * OC-147 — ReservaService.rechazar() con liberación de porciones
     */
    public void liberarPorciones(int cantidad) {
        this.porcionesComprometidas = Math.max(0, this.porcionesComprometidas - cantidad);
        recalcularEstado();
    }

    /** OC-005: cambia el total de porciones con validación. */
    public void cambiarPorcionesTotales(int nuevaCantidad) {
        if (nuevaCantidad < 1 || nuevaCantidad > 30) {
            throw new IllegalArgumentException("Las porciones deben estar entre 1 y 30");
        }
        if (nuevaCantidad < this.porcionesComprometidas) {
            throw new IllegalStateException(
                    "No puedes reducir por debajo de las porciones comprometidas: " + this.porcionesComprometidas
            );
        }
        this.porcionesTotales = nuevaCantidad;
        recalcularEstado();
    }

    /**
     * HU-24: ajusta manualmente la disponibilidad.
     *
     * OC-104 — DTO AjusteDisponibilidadRequest
     * OC-106 — ajustarDisponibilidad() en el Service
     * OC-108 — Validación "no menor que comprometidas"
     * RN-27   — Rango de porciones 1–30
     */
    public void ajustarDisponibilidad(TipoAjustePorciones tipo, Integer cantidad) {
        int comprometidasSeguras = this.porcionesComprometidas == null ? 0 : this.porcionesComprometidas;

        switch (tipo) {
            case AUMENTAR -> this.porcionesTotales = this.porcionesTotales + cantidad;
            case DISMINUIR -> this.porcionesTotales = this.porcionesTotales - cantidad;
            case MARCAR_AGOTADO -> this.porcionesTotales = comprometidasSeguras;
        }
        recalcularEstado();
    }

    /** RN-02: un plato solo está vigente si no ha expirado. */
    public boolean estaVigente() {
        return this.fechaExpiracion != null && LocalDateTime.now(java.time.ZoneId.systemDefault()).isBefore(this.fechaExpiracion);
    }
}
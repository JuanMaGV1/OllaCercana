package com.ollacercana.core.models.enums;

public enum TipoNotificacion {
    NUEVA_RESERVA,
    RESERVA_CONFIRMADA,
    RESERVA_RECHAZADA,
    RESERVA_EXPIRADA,
    RECORDATORIO,
    NUEVO_MENSAJE_CHAT,
    INVITACION_CALIFICAR,
    MODERACION_DECISION
}
